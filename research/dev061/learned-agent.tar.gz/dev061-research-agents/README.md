# DEV-061 experimental learned agents

NO_PROMOTION. These are bounded teacher-trained research candidates, not a robust general world-state model or a production release. All five TAC candidates retain learned CDL-style retrieval, neural CASM, action-conditioned prediction, and action/correction/stop logits. No scripted repair planner, teacher, simulator, or stop override runs inside the agent.

Programmed priors remain: 22-float typed public events; public categorical IDs; entity routing and fixed slot/FIFO layout in entity variants; fixed action descriptors/validity mask; masked argmax action selection. This is not learned entity discovery, symbolic program discovery, C5 scaling or validated inference under hidden/noisy state. Unfamiliar IDs expose major generalization failures.

The retention variants are separately refitted DEV-061-R1 numerical corrections. They fail the registered physical no-regression guard and are NOT promoted. The original flawed retention checkpoints and all MLP/GRU controls remain in the full evidence archive.

Python 3.12 and PyTorch 2.14.1+cpu were used. No TAC-OSM, Veritas, NumPy, teacher or training harness import is needed for inference. Install PyTorch, enter one candidate directory and run:

    python runtime.py < demo-requests.jsonl > actual.jsonl
    # Compare selected indices against demo-expected.jsonl.

Selected action indices must match exactly. CPU float telemetry can vary across hardware; the audit uses absolute tolerance1e-4 and relative tolerance1e-5 without relaxing action choices.

Each JSON line supplies reset/events/candidates/valid/queries/query_valid. Typed outputs include selected index, logits, completion estimate, current-fault probabilities, next-fault predictions and cost estimates. Demos are real public-input trajectories; their expected outputs are saved reproducibility fixtures, not a runtime controller. Completion estimates require independent execution verification.

Seed9101 was fixed in advance for this bundle. Full10-seed results, protocols, known defects and negatives are in the linked report/evidence; do not treat these five checkpoints as a favorable selection or safety guarantee.
