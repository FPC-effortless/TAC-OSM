from dataclasses import asdict
import torch
from torch import nn
from torch.nn import functional as F
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
try:
    from .learned_agent import LearnedAgent, AgentConfig, mlp
    from .temporal_agent import SparseTemporalAgent
except ImportError:
    from agent_model import LearnedAgent, AgentConfig, mlp
    from temporal_model import SparseTemporalAgent

class MemoryAgent(SparseTemporalAgent):

    def __init__(self, config, arm='generic', seed=0):
        super().__init__(AgentConfig(**config), seed, temporal='aging' in arm, sparse=True)
        self.arm = arm
        d = self.config.dimension
        self.entity = arm != 'generic'
        self.retention = 'retention' in arm
        self.state_probe = mlp(2 * d, d, 1)
        if self.entity:
            del self.address
            self.local = nn.GRU(22, d, batch_first=True)
        if self.retention:
            self.keep = mlp(22 + d, d, 1)
            nn.init.constant_(self.keep[-1].bias, 2.0)
        self.register_buffer('retention_ready', torch.tensor(False))
        if arm == 'structured_gru':
            for name in ('graph_q', 'graph_k', 'graph_v', 'graph_norm', 'operator', 'operator_selector', 'halt'):
                delattr(self, name)
        self.training_diagnostics = {}

    def initial(self, batch, device=None):
        p = next(self.parameters())
        device = device or p.device
        return (torch.zeros(batch, 32, self.config.dimension + 22, device=device), torch.zeros(batch, 33 if self.entity else 32, device=device))

    def observe(self, state, event, present=None, force_write=False):
        memory, occupied = state
        d = self.config.dimension
        if not self.entity:
            core, trace = super().observe((memory[:, :, :d], occupied), event, present, force_write)
            raw = memory[:, :, d:]
            rows = (trace['gate'] > 0).nonzero(as_tuple=True)[0]
            if len(rows):
                raw = raw.clone()
                raw[rows, trace['address'][rows]] = event[rows]
            return ((torch.cat((core[0], raw), -1), core[1]), trace)
        if not torch.isfinite(event).all():
            raise ValueError('finite public event required')
        admit = self.admission(event).squeeze(-1) >= 0
        if force_write:
            admit = torch.ones_like(admit)
        if present is not None:
            admit = admit & present.bool()
        rows = admit.nonzero(as_tuple=True)[0]
        address = torch.full((len(event),), -1, dtype=torch.long, device=event.device)
        if not len(rows):
            return (state, {'gate': admit, 'writes': 0, 'address': address, 'episodic_writes': 0})
        e = event[rows]
        slot = e[:, 4:12].argmax(-1) + 8 * (e[:, :4].argmax(-1) == 1).long()
        address[rows] = slot
        _, hidden = self.local(e[:, None], memory[rows, slot, :d][None].contiguous())
        hidden = hidden[0]
        updated = memory.clone()
        used = occupied.clone()
        updated[rows, slot] = torch.cat((hidden, e), -1)
        used[rows, slot] = 1
        keep = torch.ones(len(rows), dtype=torch.bool, device=event.device)
        if self.retention and bool(self.retention_ready):
            keep = self.keep(torch.cat((e, hidden), -1)).squeeze(-1) >= 0
        chosen = rows[keep]
        cursor = used[chosen, 32].long() % 16
        where = 16 + cursor
        updated[chosen, where] = torch.cat((self.encoder(event[chosen]), event[chosen]), -1)
        used[chosen, where] = 1
        used[chosen, 32] += 1
        return ((updated, used), {'gate': admit, 'writes': len(rows), 'address': address, 'episodic_writes': len(chosen)})

    def read(self, state, actions, uniform=False):
        memory, occupied = state
        d = self.config.dimension
        core = memory[:, :, :d]
        if self.temporal:
            core = torch.cat((core, memory[:, :, d + 21:d + 22]), -1)
        return super().read((core, occupied[:, :32]), actions, uniform)

    def forward(self, state, descriptors, valid, queries, query_valid, lesion='none'):
        mode = 'no_casm' if self.arm == 'structured_gru' else lesion
        out = LearnedAgent.forward(self, state, descriptors, valid, queries, query_valid, mode)
        reads, scores = self.read(state, self.query_encoder(queries))
        out['current_logits'] = self.state_probe(reads).squeeze(-1)
        out['state_read_logits'] = scores
        return out

def create(arm,config,seed=0):
    return MemoryAgent(config,arm,seed)
