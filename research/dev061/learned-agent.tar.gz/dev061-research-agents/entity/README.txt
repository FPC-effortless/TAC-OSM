DEV061 experimental, bounded teacher-trained policy; NOT promoted or production-certified.
Python+PyTorch only. python runtime.py < requests.jsonl
Public22-vector events,13x11 candidates,13valid mask,6x8 queries,6query_valid mask.
Generic: learned admission/addressing. Entity variants: explicit public categorical-ID routing,16 recurrent entity/relation slots+16 FIFO episodic slots; GRU updates/CDL/neural CASM/predictions/action+stop scores learned.
The public_mlp comparator deliberately uses a task-specific public feature parser.
No simulator, teacher, planner, repair rule or stop override is imported by the runtime.
Neural CASM is not symbolic program discovery. No learned continuous identity association, uncertainty/POMDP or C5-scaling claim.
Independent execution verification is still required.
