import json
from pathlib import Path
import sys
import torch
from memory_model import create
torch.set_num_threads(1)
root=Path(__file__).resolve().parent
meta=json.loads((root/'metadata.json').read_text())
if meta['arm']=='generic':
    from inference_model import InferenceMemoryAgent
    model=InferenceMemoryAgent(meta['config'],'generic').eval()
elif meta['arm']=='public_mlp':
    from inference_public_features import InferencePublicFeatureMLP
    model=InferencePublicFeatureMLP(meta['config']['width']).eval()
else:model=create(meta['arm'],meta['config']).eval()
model.load_state_dict(torch.load(root/'agent.pt',weights_only=True,map_location='cpu'),strict=True)
state=model.initial(1)
with torch.inference_mode():
    for line in sys.stdin:
        r=json.loads(line)
        if r.get('reset',False):state=model.initial(1)
        for event in r['events']:state,_=model.observe(state,torch.tensor([event],dtype=torch.float32))
        inputs=[torch.tensor([r[k]],dtype=t) for k,t in [('candidates',torch.float32),('valid',torch.bool),('queries',torch.float32),('query_valid',torch.bool)]]
        out=model(state,*inputs)
        response={'index':int(out['logits'].argmax(-1)),'logits':out['logits'][0].tolist(),
                  'completion_probability':float(out['completion'][0].sigmoid()),
                  'current_fault_probability':out['current_logits'][0].sigmoid().tolist()}
        if 'outcomes' in out:
            response['next_fault_probability']=out['outcomes'][0].sigmoid().tolist()
            response['predicted_action_cost']=(20*out['cost'][0]).tolist()
        print(json.dumps(response),flush=True)
