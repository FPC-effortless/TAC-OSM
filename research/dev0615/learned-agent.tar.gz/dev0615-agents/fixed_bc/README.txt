Research agent: Python + PyTorch only. python runtime.py < demo-requests.jsonl
Public requests: reset, keys(6x16), entity_valid(6), events(list of 38-vectors),
candidates(13x19), valid(13). Events: type4, subject16, related16, bit1, tick1.
Actions: stop/inspect/repair type3 and subject16. Padding masks only.
Declared priors: manifest slots, cosine identity binding, learned type gates and
public relationship-key stream. Learned recurrent content, predictions and policy.
Dense bounded-history replay, FIFO64. No C5 or sparse-runtime claim.
No teacher, simulator or analytic repair/stop policy in deployment.
Only bounded synthetic evidence; external outcomes need independent verification.
