Python + PyTorch only. python runtime.py < demo-request.jsonl
Input JSON: records containing the technical prestatus/recorded replacement/chlorination fields in metadata schema. Missing numeric fields remain explicitly flagged unknown.
Output: time_to_fill_20L_seconds, a factual point forecast conditioned on the recorded bundle. Units are SECONDS PER20L, not strokes or liters/second.
No entity identity, date, coordinates, text, after-functionality or observed bucket/stroke value enters inference.
This small same-survey model does not select repairs, identify causal benefits, price work, certify repair success or establish commercial reliability. Check metadata/model card for actual qualification status.
