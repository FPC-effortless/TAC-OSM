Python + PyTorch. python runtime.py < demo-requests.jsonl
Input history24x15 past contiguous ten-minute sensor-bin means, listed in source metadata.
Training-only normalization is embedded in weights. Output next sensor means/std, not health certification or a repair policy.
Source: MetroPT-3, Davari et al., UCI DOI10.24432/C5VW3R, CC BY4.0.
One real compressor; four reported failure intervals are evaluation labels only.
Gaussian marginal assumptions include binary sensors; forecast uncertainty is not calibrated physical-fault probability.
