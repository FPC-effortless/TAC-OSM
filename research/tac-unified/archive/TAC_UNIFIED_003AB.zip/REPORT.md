# TAC-UNIFIED-003A/B — neural cue encoding, adaptive evidence and factorized planning

## Summary
Five paired seeds (201–205), inheriting the exact learned quadratic transition tables from 002. Linear 32→6 classifier (198 parameters) trained for 150 Adam steps on 576 cluster-pseudolabeled cues per seed. Action identities are not used for fitting, but true labels are used to choose DEV thresholds. Fresh TEST: 640 independent chains, 655,360 decisions, 16 blocks. This is synthetic, not native CSL integration or language learning. All numbers below are from saved results, with no post-test threshold adjustment.

## 003A evidence
| Encoder | Observations | Exact chains | Cue errors | Mean reads | Mean of seed median processing ms (128 chains) |
|---|---|---:|---:|---:|---:|
| centroid | 1 | 5/640 | 6651 | 1 | 36.24 |
| centroid | 3 | 639/640 | 2 | 3 | 86.11 |
| centroid | 5 | 640/640 | 0 | 5 | 128.83 |
| centroid | adaptive | 637/640 | 3 | 1.2861 | 53.43 |
| neural | 1 | 3/640 | 8633 | 1 | 37.72 |
| neural | 3 | 634/640 | 11 | 3 | 91.83 |
| neural | 5 | 640/640 | 0 | 5 | 143.24 |
| neural | adaptive | 635/640 | 6 | 1.5841 | 66.57 |

Per-seed neural adaptive exact accuracy: 100%, 100%, 96.875%, 99.21875%, 100%; all read counts below three. Seed 203 misses both accuracy and noninferiority gates. Overall 003A qualification FAIL (not all per-seed gates pass). Centroid is a stronger simpler control, and aggregate success is not all-seed success. CPU timings exploratory, pre-generated observations (no acquisition cost), scoring and execution only; no fit or calibration cost.

## Planning
64 distinct pairs per seed per block-count. 1/4/16/32 blocks (8/32/128/256 bits); all 1280 plans and cached plans achieve goals and match shortest independent local distances. 32-block cases 320/320 correct, mean 52.34 actions, maximum 79. Mathematically, with independent local transitions and unit additive action cost, every path projects to a valid path in each block, so its length is at least sum of local distances; concatenation achieves that bound. Independence, shared transition rules, block IDs and the local operator family are supplied. Goals sampled reachable (8 random actions per block); not coverage of arbitrary global states. Global BFS diagnostic at two blocks: 40/40 same lengths; median across seed means 0.14485 ms global vs 0.00962 ms factorized planning (about 15.05×, planning only). 32-block plan+execution: median of seed medians 162.75 us local BFS vs 33.82 us cached, ~4.81× (median paired ratio 4.75×). Full local reverse cache median preparation 130.91 ms, not included in warmed timings. Cross-block interference falsifier succeeds in only 1/320 32-block cases (0.3125%); independence violation is catastrophic. No empirical parallel speedup measured.

## 003B prospective follow-up
Fresh held-out seeds, exact eight-bit flip channel, 640 chains/655360 decisions. Learned centroids exactly match true codes in evaluation audit. Track candidate intersection across observations; accept singleton, abstain on empty or at cap. Exact channel: 640/640 chains correct, 0 incorrect accepts, 0 abstentions, 1.015425 reads/action, mean of seed median processing 50.13 ms vs fixed5 95.51 ms (same 640/640; ~1.91×). Reads reduced 79.69%. This is a conditional certificate only: under exact channel and correct codebook, true class always remains in the set. Variable 7/8/9-flip stress: 0/640 chains correct, 2,132 wrong accepted decisions, 436,955 abstentions; fixed5 Hamming 640/640 (0 errors). The certificate is invalid under channel misspecification, not a general confidence guarantee. No retrospective adjustment to 003A.

## Reproducibility
Python and torch/NumPy versions in results.json. Run `python run.py` then `python certificate.py` from this directory; prior002 includes inherited data/code. `run_original.py` is the executed A source; later import-only repair uses explicitly named prior module so B can import A. Original B failure preserved in certificate_initial_failure.log (module name collision, no completed experimental records). No code/experiment modifications to original repos. `results.json` and `certificate.json` are actual saved outcomes; raw times retained. No independent external reproduction, general language, full neural architecture, learned factorization or hardware parallelism claim.

## Next experiment
Learn action effects and dependency graph jointly, test coupled worlds with unseen combinations and changed cue distributions; compare exact verified executor with neural-only and factorized baselines. Learn a channel-robust evidence policy with an explicit abstention/recovery budget; freeze separate validation and holdout. Integrate native CSL only after the learned interface is verified; profile end-to-end cost and test natural communication subsequently.
