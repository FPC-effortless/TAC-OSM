import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
import sys,pathlib,json,time,itertools,collections,platform
import numpy as np, torch
from torch import nn
BASE=pathlib.Path(__file__).parent
sys.path.insert(0,str(BASE/'prior002' if (BASE/'prior002').exists() else BASE.parent/'tac_unified_002'))
import importlib.util
prior_path=BASE/'prior002'/'run.py' if (BASE/'prior002').exists() else BASE.parent/'tac_unified_002'/'run.py'
spec=importlib.util.spec_from_file_location('tac_prior002',prior_path)
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
# prior module import works when this script is executed as __main__.
torch.set_num_threads(1);K=6;C=32;N=256

def reconstruct(seed,row):
 r=np.random.default_rng(seed);gates=list(itertools.permutations(range(8),3));r.choice(len(gates),K,replace=False)
 while True:
  code=r.integers(0,2,(K,C),dtype=np.uint8)
  if min(np.count_nonzero(code[i]!=code[j]) for i,j in itertools.combinations(range(K),2))>=12:break
 p=r.permutation(N);train=p[:96];ids=np.repeat(np.arange(K),len(train));cue=prior.noise(r,code[ids],2);sh=r.permutation(len(ids));cue=cue[sh];cs,z=prior.cluster(cue);mapping=np.array(row['mapping']);assert np.all(mapping[z]==ids[sh]);return code, cue,cs,z,mapping

def noisy(r,x):
 x=x.copy();f=np.argpartition(r.random(x.shape,dtype=np.float32),7,axis=1)[:,:8];x[np.arange(len(x))[:,None],f]^=1;return x

def exec_multi(tab,s,b,a):
 s=s.copy();rr=np.arange(len(s))
 for j in range(a.shape[1]):s[rr,b[:,j]]=tab[a[:,j],s[rr,b[:,j]]]
 return s

def fixtures(r,code,truth,inv,n):
 a=r.integers(K,size=(n,1024));b=r.integers(16,size=a.shape);s=r.integers(N,size=(n,16));x=code[a].reshape(-1,C);obs=[noisy(r,x) for _ in range(5)];return a,b,s,obs,exec_multi(truth,s,b,inv[a])

def decode(obs,score,lim,th):
 n=len(obs[0]);alive=np.arange(n);acc=np.zeros((n,K),np.float32);pred=np.empty(n,int);count=np.empty(n,np.uint8)
 for i in range(lim):
  if not len(alive):break
  acc[alive]+=score(obs[i][alive]);v=acc[alive];p=v.argmax(1)
  if i==lim-1:done=np.ones(len(alive),bool)
  elif th is None:done=np.zeros(len(alive),bool)
  else:
   top=np.partition(v,-2,axis=1)[:,-2:];done=top[:,1]-top[:,0]>=th
  pred[alive[done]]=p[done];count[alive[done]]=i+1;alive=alive[~done]
 return pred,count

def eval_arm(f,score,tab,mapping,lim,th):
 a,b,s,obs,y=f;t=time.perf_counter_ns();p,c=decode(obs,score,lim,th);out=exec_multi(tab,s,b,p.reshape(a.shape));ms=(time.perf_counter_ns()-t)/1e6
 return dict(cue=float(np.mean(mapping[p]==a.ravel())),errors=int(np.sum(mapping[p]!=a.ravel())),exact=float(np.mean(np.all(out==y,1))),reads=float(c.mean()),ms=ms)

def local_plan(tab,s,g,cache=None):
 p=[]
 for b,(x,y) in enumerate(zip(s,g)):
  v=prior.bfs(tab,int(x),int(y))[0] if cache is None else prior.cached(cache[int(y)],int(x),int(y))
  if v is None:return None
  p.extend((b,a) for a in v)
 return p

def execute(tab,s,p,coupled=False):
 if p is None:return None
 s=s.copy()
 for b,a in p:
  s[b]=tab[a,s[b]]
  if coupled and a==0 and len(s)>1:s[(b+1)%len(s)]^=1
 return s

def global_bfs(tab,s,g):
 s,g=tuple(s),tuple(g);q=collections.deque([(s,0)]);seen={s};exp=0
 while q:
  x,d=q.popleft();exp+=1
  if x==g:return d,exp
  for b in range(len(s)):
   for a in range(K):
    y=x[:b]+(int(tab[a,x[b]]),)+x[b+1:]
    if y not in seen:seen.add(y);q.append((y,d+1))
 return None,exp

def goal(r,truth,B):
 while True:
  s=r.integers(N,size=B);g=s.copy()
  for _ in range(8):g=truth[r.integers(K,size=B),g]
  if not np.array_equal(s,g):return s,g

def run(row):
 seed=row['seed'];r=np.random.default_rng(seed+30000);torch.manual_seed(seed);code,cue,cs,z,mapping=reconstruct(seed,row);inv=np.argsort(mapping);tab=np.array(row['tables']['quad']);truth=np.array(row['true_table']);assert np.array_equal(tab,truth)
 net=nn.Linear(C,K);opt=torch.optim.Adam(net.parameters(),lr=.05);tx=torch.from_numpy(cue.astype(np.float32)*2-1);ty=torch.from_numpy(z.astype(np.int64));losses=[]
 for _ in range(150):
  opt.zero_grad();loss=nn.functional.cross_entropy(net(tx),ty);loss.backward();opt.step();losses.append(float(loss.detach()))
 w=net.weight.detach().numpy().copy();bias=net.bias.detach().numpy().copy();cw=(2*cs.astype(np.float32)-1)/2
 scorers={'centroid':lambda x:(2*x.astype(np.float32)-1)@cw.T,'neural':lambda x:(2*x.astype(np.float32)-1)@w.T+bias}
 dev=fixtures(np.random.default_rng(seed+10000),code,truth,inv,32);ev=fixtures(np.random.default_rng(seed+20000),code,truth,inv,128)
 out=dict(seed=seed,weights=w.tolist(),bias=bias.tolist(),train_loss=[losses[0],losses[-1]],arms={},planning={},global_bfs={})
 for name,sc in scorers.items():
  grid=list(range(2,25,2)) if name=='centroid' else [.5,1,2,3,4,6,8,12,16,24,32];cal=[dict(threshold=th,**eval_arm(dev,sc,tab,mapping,5,th)) for th in grid];good=[v for v in cal if v['errors']==0];chosen=min(good,key=lambda v:v['reads'])['threshold'] if good else None
  res=dict(calibration=cal,threshold=chosen,fallback=not bool(good),fixed={})
  for label,lim,th in [('1',1,None),('3',3,None),('5',5,None),('adaptive',5,chosen)]:
   eval_arm(ev,sc,tab,mapping,lim,th);runs=[eval_arm(ev,sc,tab,mapping,lim,th) for _ in range(3)];res['fixed'][label]={**runs[0],'ms':float(np.median([v['ms'] for v in runs])),'raw_ms':[v['ms'] for v in runs]}
  out['arms'][name]=res
 t=time.perf_counter_ns();cache={g:prior.reverse(tab,g) for g in range(N)};out['cache_build_ms']=(time.perf_counter_ns()-t)/1e6
 for B in [1,4,16,32]:
  qs=[];seen=set()
  while len(qs)<64:
   s,g=goal(r,truth,B);key=tuple(s)+tuple(g)
   if key not in seen:qs.append((s,g));seen.add(key)
  oracle=[sum(len(prior.bfs(truth,int(x),int(y))[0]) for x,y in zip(s,g)) for s,g in qs];p=[local_plan(tab,s,g) for s,g in qs];ok=[np.array_equal(execute(truth,s,v),g) for (s,g),v in zip(qs,p)];opt=[k and len(v)==l for k,v,l in zip(ok,p,oracle)];bad=[np.array_equal(execute(truth,s,v,True),g) for (s,g),v in zip(qs,p)];cp=[local_plan(tab,s,g,cache) for s,g in qs];times={'local':[],'cache':[]}
  for i in range(3):
   for key in (['local','cache'] if i%2==0 else ['cache','local']):
    t=time.perf_counter_ns()
    for s,g in qs:execute(tab,s,local_plan(tab,s,g,cache if key=='cache' else None))
    times[key].append((time.perf_counter_ns()-t)/len(qs)/1000)
  out['planning'][B]=dict(success=float(np.mean(ok)),optimal=float(np.mean(opt)),coupled=float(np.mean(bad)),cached_correct=float(np.mean([np.array_equal(execute(truth,s,v),g) for (s,g),v in zip(qs,cp)])),mean_length=float(np.mean(oracle)),max_length=max(oracle),times_us=times)
 qs=[goal(r,truth,2) for _ in range(8)];t=time.perf_counter_ns();gp=[global_bfs(tab,s,g) for s,g in qs];gt=(time.perf_counter_ns()-t)/8/1e6;t=time.perf_counter_ns();lp=[local_plan(tab,s,g) for s,g in qs];lt=(time.perf_counter_ns()-t)/8/1e6;out['global_bfs']=dict(global_ms=gt,local_ms=lt,global_expansions=float(np.mean([e for _,e in gp])),same_length=float(np.mean([len(p)==v for p,(v,e) in zip(lp,gp)])))
 return out
if __name__=='__main__':
 p=BASE/'prior002' if (BASE/'prior002').exists() else BASE.parent/'tac_unified_002';rows=json.loads((p/'results.json').read_text())['runs'];results=dict(environment=dict(python=platform.python_version(),torch=torch.__version__,numpy=np.__version__,threads=1),runs=[])
 for row in rows:
  v=run(row);results['runs'].append(v);(BASE/'results.json').write_text(json.dumps(results,indent=2));print(v['seed'],{k:a['fixed']['adaptive'] for k,a in v['arms'].items()},v['planning'][32],flush=True)
