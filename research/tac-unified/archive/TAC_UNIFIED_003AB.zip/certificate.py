import run as m
import numpy as np, json,time
from pathlib import Path

def variable(r,x):
 x=x.copy();rank=np.argpartition(r.random(x.shape,dtype=np.float32),8,axis=1)[:,:9];n=r.integers(7,10,size=len(x));rr,cc=np.nonzero(np.arange(9)[None,:]<n[:,None]);x[rr,rank[rr,cc]]^=1;return x

def fixture(r,code,truth,inv,n,variable_noise):
 a=r.integers(m.K,size=(n,1024));b=r.integers(16,size=a.shape);s=r.integers(m.N,size=(n,16));x=code[a].reshape(-1,m.C);obs=[variable(r,x) if variable_noise else m.noisy(r,x) for _ in range(5)];return a,b,s,obs,m.exec_multi(truth,s,b,inv[a])

def cert(obs,cs):
 n=len(obs[0]);alive=np.arange(n);possible=np.ones((n,m.K),bool);p=np.full(n,-1,int);count=np.empty(n,np.uint8)
 for i,x in enumerate(obs):
  if not len(alive):break
  dist=np.count_nonzero(x[alive,None,:]!=cs[None,:,:],axis=2);possible[alive]&=dist==8;v=possible[alive];k=v.sum(1);done=(k<=1)|(i==4);one=k==1;idx=alive[one];p[idx]=v[one].argmax(1);count[alive[done]]=i+1;alive=alive[~done]
 return p,count

def evaluate(f,cs,mapping,tab):
 a,b,s,obs,y=f;t=time.perf_counter_ns();p,c=cert(obs,cs);pred=p.reshape(a.shape);out=m.exec_multi(tab,s,b,np.maximum(pred,0));ok=np.all(out==y,1)&np.all(pred>=0,1);ms=(time.perf_counter_ns()-t)/1e6
 return dict(exact=float(ok.mean()),wrong=int(np.sum((p>=0)&(mapping[np.maximum(p,0)]!=a.ravel()))),abstentions=int(np.sum(p<0)),reads=float(c.mean()),ms=ms)
if __name__=='__main__':
 rows=json.loads((m.BASE/'prior002/results.json').read_text())['runs'];out=[]
 for row in rows:
  seed=row['seed'];code,cue,cs,z,mapping=m.reconstruct(seed,row);tab=np.array(row['tables']['quad']);truth=np.array(row['true_table']);inv=np.argsort(mapping);rec=dict(seed=seed,code_exact=bool(np.array_equal(cs,code[mapping])),arms={});cw=(2*cs.astype(np.float32)-1)/2;sc=lambda x:(2*x.astype(np.float32)-1)@cw.T
  for name,noise in [('exact8',False),('variable789',True)]:
   f=fixture(np.random.default_rng(seed+40000+int(noise)*1000),code,truth,inv,128,noise);evaluate(f,cs,mapping,tab);m.eval_arm(f,sc,tab,mapping,5,None);v=[evaluate(f,cs,mapping,tab) for _ in range(3)];w=[m.eval_arm(f,sc,tab,mapping,5,None) for _ in range(3)];rec['arms'][name]={'certificate':{**v[0],'ms':float(np.median([q['ms'] for q in v])),'raw_ms':[q['ms'] for q in v]},'fixed5':{**w[0],'ms':float(np.median([q['ms'] for q in w])),'raw_ms':[q['ms'] for q in w]}}
  out.append(rec);(m.BASE/'certificate.json').write_text(json.dumps(out,indent=2));print(rec,flush=True)
