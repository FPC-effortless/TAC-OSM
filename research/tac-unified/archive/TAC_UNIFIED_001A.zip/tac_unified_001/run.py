import numpy as np, torch, time, json, collections, platform
from pathlib import Path
from torch import nn
torch.set_num_threads(1)
D=8; K=6

def elim(x,y):
 a=np.concatenate((x,y),1).copy(); p=0
 for j in range(x.shape[1]):
  w=np.flatnonzero(a[p:,j]);
  if not len(w):continue
  k=p+w[0];a[[p,k]]=a[[k,p]]
  for i in range(len(a)):
   if i!=p and a[i,j]:a[i]^=a[p]
  p+=1
 return p,a

def aug(x):return np.concatenate((x,np.ones((*x.shape[:-1],1),np.uint8)),-1)
def mul(x,m):return (x@m)&1
def learn(x,y):
 p,a=elim(aug(x),y);assert p==9 and not a[p:,9:].any(); m=np.zeros((9,9),np.uint8);m[:,:8]=a[:9,9:];m[8,8]=1;return m

def gen(r):
 while True:
  a=r.integers(0,2,(8,8),dtype=np.uint8)
  if elim(a,np.zeros((8,0),np.uint8))[0]==8:break
 m=np.zeros((9,9),np.uint8);m[:8,:8]=a;m[8,:8]=r.integers(0,2,8,dtype=np.uint8);m[8,8]=1;return m

def compose(seq,ops):
 m=np.eye(9,dtype=np.uint8)
 for a in seq:m=mul(m,ops[a])
 return m

def execute(x,seq,ops,macros=None):
 s=aug(x);i=k=0
 while i<len(seq):
  found=False
  if macros:
   for n in (4,3,2):
    key=seq[i:i+n]
    if len(key)==n and key in macros:s=mul(s,macros[key]);i+=n;found=True;break
  if not found:s=mul(s,ops[seq[i]]);i+=1
  k+=1
 return s[...,:8],k

def batch(x,seqs,ops):
 s=aug(x)
 for a in seqs.T:s=np.einsum('bi,bij->bj',s,ops[a])&1
 return s[:,:8]
def acc(a,b):return float(np.mean(np.all(a==b,-1)))
def pattern(r,n):
 out=[];pool=((0,2,1,4),(5,3,0),(2,4,5,1))
 while len(out)<n:
  if r.random()<.8:out.extend(pool[r.integers(3)])
  else:out.append(int(r.integers(6)))
 return tuple(out[:n])
class Net(nn.Module):
 def __init__(self):super().__init__();self.net=nn.Sequential(nn.Linear(14,64),nn.GELU(),nn.Linear(64,64),nn.GELU(),nn.Linear(64,8))
 def forward(self,x,a):return self.net(torch.cat((x,nn.functional.one_hot(a,6).float()),-1))

def run(seed):
 r=np.random.default_rng(seed);torch.manual_seed(seed);world=np.stack([gen(r) for _ in range(6)]);states=((np.arange(256)[:,None]>>np.arange(8))&1).astype(np.uint8);p=r.permutation(256);train=states[p[:48]];test=states[p[48:]];tx=np.repeat(train[None,:,:],6,axis=0);ty=np.stack([mul(aug(train),m)[:,:8] for m in world]);ops=np.stack([learn(x,y) for x,y in zip(tx,ty)])
 net=Net();opt=torch.optim.AdamW(net.parameters(),lr=.003);xt=torch.tensor(tx.reshape(-1,8),dtype=torch.float32);yt=torch.tensor(ty.reshape(-1,8),dtype=torch.float32);at=torch.arange(6).repeat_interleave(48)
 for _ in range(500):
  opt.zero_grad();loss=nn.functional.binary_cross_entropy_with_logits(net(xt,at),yt);loss.backward();opt.step()
 res={'seed':seed,'operator_exact':bool(np.array_equal(ops,world)),'parameters':sum(p.numel() for p in net.parameters()),'chains':{}}
 for l in (1,2,4,8,16,32):
  if l==1:x=np.tile(test,(6,1));seqs=np.repeat(np.arange(6),len(test))[:,None]
  else:x=test[r.integers(len(test),size=256)];seqs=r.integers(6,size=(256,l))
  y=batch(x,seqs,world);s=x.copy();ns=torch.tensor(x,dtype=torch.float32)
  with torch.no_grad():
   for a in seqs.T:
    s=ty[a,np.argmin(np.count_nonzero(s[:,None,:]!=tx[a],axis=-1),axis=1)];ns=(net(ns,torch.tensor(a))>0).float()
  res['chains'][l]={'n':len(x),'affine':acc(batch(x,seqs,ops),y),'nearest':acc(s,y),'neural':acc(ns.numpy(),y),'shuffled':acc(batch(x,seqs,np.roll(ops,1,axis=0)),y)}
 discovery=[pattern(r,12) for _ in range(96)];counts=collections.Counter(s[i:i+n] for s in discovery for n in (2,3,4) for i in range(len(s)-n+1));valid=[]
 for _ in range(48):
  seq=pattern(r,12);st=[train[r.integers(48)]]
  for a in seq:st.append(execute(st[-1],(a,),world)[0])
  valid.append((seq,st))
 macros={}; supports={}
 for key,support in counts.items():
  if support<12:continue
  n=len(key);m=compose(key,ops);checks=[np.array_equal(mul(aug(st[i]),m)[:8],st[i+n]) for s,st in valid for i in range(len(s)-n+1) if s[i:i+n]==key]
  if len(checks)>=8 and all(checks):macros[key]=m;supports[key]=support
 q=[(test[r.integers(len(test))],pattern(r,32)) for _ in range(256)];a=[];steps=[]
 for x,seq in q:
  y,_=execute(x,seq,world);z,n=execute(x,seq,ops,macros);a.append(np.array_equal(y,z));steps.append(n)
 res['macros']={'count':len(macros),'accuracy':float(np.mean(a)),'steps':float(np.mean(steps)),'saving':1-float(np.mean(steps))/32}
 key=max(supports,key=supports.get);bad={k:v.copy() for k,v in macros.items()};bad[key][8,0]^=1;rejected=[k for k,m in bad.items() if not np.array_equal(m,compose(k,ops))];fixed={k:compose(k,ops) if k in rejected else m for k,m in bad.items()};x=np.stack([x for x,s in q]);y=execute(x,key,ops)[0];res['repair']={'detected':rejected==[key],'corrupt':acc(execute(x,key,ops,bad)[0],y),'repaired':acc(execute(x,key,ops,fixed)[0],y)}
 x=test[r.integers(len(test),size=64)];y=x.copy();carry=x.copy();cs=[];rs=[]
 for _ in range(8):
  seqs=r.integers(6,size=(64,2));y=batch(y,seqs,world);carry=batch(carry,seqs,ops);cs.append(acc(carry,y));rs.append(acc(batch(x,seqs,ops),y))
 res['persistent']={'carry':np.mean(cs),'reset':np.mean(rs),'reset_turns':rs}
 for x,s in q[:32]:execute(x,s,ops);execute(x,s,ops,macros)
 times={'primitive':[],'macro':[]}
 for i in range(9):
  for name,lib in ([('primitive',None),('macro',macros)] if i%2==0 else [('macro',macros),('primitive',None)]):
   t=time.perf_counter_ns()
   for x,s in q:execute(x,s,ops,lib)
   times[name].append((time.perf_counter_ns()-t)/256/1000)
 res['timing_us']=times;res['learned_operators']=ops.tolist();res['world_operators']=world.tolist();return res
if __name__=='__main__':
 out={'environment':{'python':platform.python_version(),'numpy':np.__version__,'torch':torch.__version__,'threads':torch.get_num_threads()},'runs':[]}
 for seed in range(101,106):
  a=run(seed);out['runs'].append(a);print(seed,a['chains'][32],a['macros'],a['persistent'],flush=True);Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2))
