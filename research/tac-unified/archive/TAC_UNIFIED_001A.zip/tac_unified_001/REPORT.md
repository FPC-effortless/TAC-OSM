# TAC-UNIFIED-001A results

All five seeds pass the pilot mechanism gates. Independent synthetic CPU prototype; not native CSL or a qualified comparative study.

| Chain length | Structural exact | Neural MLP exact | Nearest exact | Shuffled operator exact |
|---:|---:|---:|---:|---:|
| 1 | 100.000% | 0.481% | 0.000% | 0.369% |
| 2 | 100.000% | 0.234% | 0.703% | 0.469% |
| 4 | 100.000% | 0.156% | 0.234% | 0.234% |
| 8 | 100.000% | 0.156% | 0.547% | 0.312% |
| 16 | 100.000% | 0.469% | 0.547% | 0.078% |
| 32 | 100.000% | 0.312% | 0.469% | 0.625% |

Mean across seeds: 9.403125 executed operations per 32-operation patterned request (70.615% reduction). Primitive-only average of per-seed round medians 76.071 microseconds, cached 25.241 microseconds (3.014x). All 1280 patterned queries exact. Persistent carry 100%, reset 12.890625% over 2560 turns. All five deliberately corrupted macros detected at audit and repaired, restoring all evaluated outputs.

The learner recovers affine maps with Gaussian elimination from exact transition labels. The affine family, primitive IDs and ordered commands are supplied. Pattern mining uses additional action sequences and verification trajectories unavailable to the primitive baselines; macro speedup is compared to the identical learned primitive executor. No parameter/compute parity, language, neural integration, autonomous goal selection, general reasoning or external independent replication. Timing is means per round, not individual request median/p95; one host and fixed patterned workload. Macro setup and audit excluded from warmed timings.

Reproduce: Python with NumPy and PyTorch CPU, `python run.py`. Original per-seed results and raw timing round means are in results.json.
