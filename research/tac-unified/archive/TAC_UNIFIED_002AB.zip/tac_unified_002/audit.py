"""Independent saved-table and graph audit; does not import run.py."""
import json,collections
from pathlib import Path
import numpy as np
p=Path(__file__).parent; r=json.loads((p/'results.json').read_text())['runs'];summary=[]
for row in r:
 t=np.array(row['true_table']);q=np.array(row['tables']['quad']);assert np.array_equal(t,q)
 assert all(len(set(a))==256 for a in q)
 # Independently derive actual conditional transitions from saved rule indices and permutation.
 for j,w in enumerate(row['mapping']):
  i,k,b=row['rules'][w]
  expect=[s ^ (((((s>>i)&1)&((s>>k)&1))^(w%2))<<b) for s in range(256)]
  assert np.array_equal(expect,t[j])
 # Floyd-Warshall independent shortest path oracle on complete graph.
 d=np.full((256,256),1000,dtype=np.int32);np.fill_diagonal(d,0)
 for a in t:
  for i,j in enumerate(a):
   if i!=j:d[i,j]=1
 for k in range(256):d=np.minimum(d,d[:,k,None]+d[None,k,:])
 lengths=[int(d[s,g]) for s,g in row['goal_cases']];assert all(0<l<=16 for l in lengths)
 gates={'cue_partition':row['partition']>=.95,'unseen_primitive':row['primitive']['2']['quad']>=.95,'depth1024':row['chains']['1024']['2']['quad']>=.95,'goals':row['goal']['quad']['success']>=.95,'optimal':row['goal']['quad']['optimal']>=.95,'cache':row['cache']['cached_accuracy']>=.95}
 assert all(gates.values())
 summary.append({'seed':row['seed'],'table_entries':int(t.size),'goal_pairs':len(lengths),'mean_oracle_path':float(np.mean(lengths)),'max_oracle_path':max(lengths),'max_reachable_component':int((d<1000).sum(1).max()),'gates':gates})
(p/'audit.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
