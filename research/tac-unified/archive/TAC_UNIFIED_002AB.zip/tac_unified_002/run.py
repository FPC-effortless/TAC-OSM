import numpy as np, time, json, itertools, collections, platform
from pathlib import Path
D=8; K=6; C=32; N=256
BITS=((np.arange(N)[:,None]>>np.arange(D))&1).astype(np.uint8)
POW=2**np.arange(D); PAIRS=list(itertools.combinations(range(D),2))
def feat(x,quad):
 return np.concatenate([np.ones((len(x),1),np.uint8),x]+([np.stack([x[:,i]&x[:,j] for i,j in PAIRS],1)] if quad else []),1)
def fit(x,y,quad):
 f=feat(x,quad); a=np.concatenate([f,y],1); p=0; cols=[]
 for j in range(f.shape[1]):
  w=np.flatnonzero(a[p:,j]);
  if not len(w):continue
  k=p+w[0];a[[p,k]]=a[[k,p]]
  mask=a[:,j].astype(bool);mask[p]=False;a[mask]^=a[p];cols.append(j);p+=1
 m=np.zeros((f.shape[1],D),np.uint8);m[cols]=a[:p,f.shape[1]:];return m,p,int(np.any(a[p:,f.shape[1]:],1).sum())
def noise(r,c,n):
 out=c.copy().reshape(-1,C)
 for row in out:row[r.choice(C,n,replace=False)]^=1
 return out.reshape(c.shape)
def classify(c,cent):return np.count_nonzero(c[...,None,:]!=cent,axis=-1).argmin(-1)
def cluster(x):
 cs=[x[0]]
 for _ in range(K-1):cs.append(x[np.count_nonzero(x[:,None,:]!=np.stack(cs),axis=-1).min(1).argmax()])
 cs=np.stack(cs)
 for _ in range(10):
  z=classify(x,cs);new=np.stack([(x[z==i].sum(0)*2>=sum(z==i)).astype(np.uint8) if any(z==i) else cs[i] for i in range(K)])
  if np.array_equal(new,cs):break
  cs=new
 return cs,classify(x,cs)
def bfs(tab,s,g):
 if s==g:return [],0
 q=collections.deque([s]);prev={s:None};exp=0
 while q:
  x=q.popleft();exp+=1
  for a,y in enumerate(tab[:,x]):
   y=int(y)
   if y<0 or y in prev:continue
   prev[y]=(x,a)
   if y==g:
    path=[]
    while y!=s:y,a=prev[y];path.append(a)
    return path[::-1],exp
   q.append(y)
 return None,exp
def reverse(tab,g):
 # only compiled learned graph, no environment
 rev=[[] for _ in range(N)]
 for x in range(N):
  for a,y in enumerate(tab[:,x]):
   if y>=0:rev[int(y)].append((x,a))
 q=collections.deque([g]);d={g:None}
 while q:
  y=q.popleft()
  for x,a in rev[y]:
   if x not in d:d[x]=(y,a);q.append(x)
 return d
def cached(d,s,g):
 if s not in d:return None
 p=[]
 while s!=g:s,a=d[s];p.append(a)
 return p
def execute(tab,s,p):
 if p is None or len(p)>16:return -1
 for a in p:s=int(tab[a,s]);
 return s
def chain(tab,start,acts):
 s=start.copy()
 for a in acts.T:
  good=s>=0;s=np.where(good,tab[a,np.maximum(s,0)],-1)
 return s
def run(seed):
 r=np.random.default_rng(seed)
 gates=list(itertools.permutations(range(D),3)); chosen=r.choice(len(gates),K,replace=False); rules=[gates[i] for i in chosen]
 world=np.empty((K,N),int)
 for a,(i,j,k) in enumerate(rules):
  y=BITS.copy();y[:,k]^=(BITS[:,i]&BITS[:,j])^(a%2);world[a]=y@POW
 while True:
  code=r.integers(0,2,(K,C),dtype=np.uint8)
  if min(np.count_nonzero(code[i]!=code[j]) for i,j in itertools.combinations(range(K),2))>=12:break
 p=r.permutation(N);train=p[:96];test=p[96:]; ids=np.repeat(np.arange(K),len(train)); xs=np.tile(train,K);ys=world[ids,xs];cues=noise(r,code[ids],2);sh=r.permutation(len(ids));ids,xs,ys,cues=ids[sh],xs[sh],ys[sh],cues[sh]
 cent,z=cluster(cues);perm=max(itertools.permutations(range(K)),key=lambda p:np.sum(np.array(p)[z]==ids)); mapping=np.array(perm); inv=np.argsort(mapping); truth=world[mapping];part=float(np.mean(mapping[z]==ids)); tables={};diagn={}
 for name,quad in [('quad',True),('affine',False)]:
  a=[];diag=[]
  for j in range(K):
   m,rank,res=fit(BITS[xs[z==j]],BITS[ys[z==j]],quad);a.append(((feat(BITS,quad)@m)&1)@POW);diag.append([rank,res])
  tables[name]=np.stack(a);diagn[name]=diag
 lookup=np.full((K,N),-1,int);lookup[z,xs]=ys;tables['lookup']=lookup
 out={'seed':seed,'partition':part,'fit_diagnostics':diagn,'rules':rules,'mapping':mapping.tolist(),'primitive':{},'chains':{},'goal':{}}
 for n in [2,4,8]:
  a=np.repeat(np.arange(K),len(test));s=np.tile(test,K);pred=classify(noise(r,code[a],n),cent);y=world[a,s];out['primitive'][n]={'cue':float(np.mean(mapping[pred]==a)),**{k:float(np.mean(t[pred,s]==y)) for k,t in tables.items()}}
 for l in [1,8,32,64,128,256,1024]:
  a=r.integers(K,size=(256,l));s=r.choice(test,256);y=chain(world,s,a);d={}
  for n in [2,8]:
   pred=classify(noise(r,code[a],n),cent);d[n]={'cue':float(np.mean(mapping[pred]==a)),**{k:float(np.mean(chain(t,s,pred)==y)) for k,t in tables.items() if n==2 or k=='quad'}}
  out['chains'][l]=d
 qs=set()
 while len(qs)<128:
  s=int(r.choice(test));g=s
  for a in r.integers(K,size=8):g=int(world[a,g])
  if s!=g:qs.add((s,g))
 qs=sorted(qs);oracle=[bfs(truth,s,g)[0] for s,g in qs]
 for k,t in tables.items():
  plans=[bfs(t,s,g) for s,g in qs];out['goal'][k]={'success':float(np.mean([execute(truth,s,p)==g for (s,g),(p,e) in zip(qs,plans)])),'optimal':float(np.mean([p is not None and len(p)==len(o) and execute(truth,s,p)==g for (s,g),(p,e),o in zip(qs,plans,oracle)])),'expansions':float(np.mean([e for p,e in plans]))}
 # Fixed goals selected from training states reachable from heldout starts; cache build included separately.
 goals=[int(g) for g in train if any(bfs(tables['quad'],int(s),int(g))[0] for s in test)][:16];q=[]
 for g in goals:
  s=[int(x) for x in test if bfs(tables['quad'],int(x),g)[0]];q.extend((int(x),g) for x in r.choice(s,8,replace=len(s)<8))
 tab=tables['quad'];t=time.perf_counter_ns();cache={g:reverse(tab,g) for g in goals};prep=(time.perf_counter_ns()-t)/1000
 out['cache']={'queries':len(q),'goals':len(goals),'build_us':prep,'entries':sum(map(len,cache.values())),'cached_accuracy':float(np.mean([execute(truth,s,cached(cache[g],s,g))==g for s,g in q])),'bfs_accuracy':float(np.mean([execute(truth,s,bfs(tab,s,g)[0])==g for s,g in q])),'times':{'bfs':[],'cached':[]}}
 for i in range(7):
  for name in (['bfs','cached'] if i%2==0 else ['cached','bfs']):
   t=time.perf_counter_ns()
   for s,g in q:execute(tab,s,bfs(tab,s,g)[0] if name=='bfs' else cached(cache[g],s,g))
   out['cache']['times'][name].append((time.perf_counter_ns()-t)/len(q)/1000)
 out['tables']={k:t.tolist() for k,t in tables.items()};out['true_table']=truth.tolist();out['goal_cases']=qs
 return out
if __name__=='__main__':
 out={'environment':{'python':platform.python_version(),'numpy':np.__version__},'runs':[]}
 for seed in range(201,206):
  x=run(seed);out['runs'].append(x);Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2));print(seed,x['partition'],x['primitive'][2],x['chains'][1024],x['goal'],flush=True)
