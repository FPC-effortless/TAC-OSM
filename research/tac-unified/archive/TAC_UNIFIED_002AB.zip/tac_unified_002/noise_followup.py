from run import *
def run_follow(seed,row):
 r=np.random.default_rng(seed);gates=list(itertools.permutations(range(D),3));r.choice(len(gates),K,replace=False)
 while True:
  code=r.integers(0,2,(K,C),dtype=np.uint8)
  if min(np.count_nonzero(code[i]!=code[j]) for i,j in itertools.combinations(range(K),2))>=12:break
 p=r.permutation(N);train=p[:96];test=p[96:];ids=np.repeat(np.arange(K),len(train));cue=noise(r,code[ids],2);sh=r.permutation(len(ids));cent,z=cluster(cue[sh]);mapping=np.array(row['mapping']);assert np.all(mapping[z]==ids[sh]);t=np.array(row['tables']['quad']);truth=np.array(row['true_table']);rd=np.random.default_rng(seed+9000);a=rd.integers(K,size=(128,1024));s=rd.choice(test,128);y=chain(truth,s,np.argsort(mapping)[a]);pbase=code[a].reshape(-1,C);obs=[]
 for _ in range(5):
  # Uniform subset of 8 indices by independently generated continuous ranks.
  f=np.argpartition(rd.random(pbase.shape,dtype=np.float32),7,axis=1)[:,:8];c=pbase.copy();c[np.arange(len(c))[:,None],f]^=1;obs.append(c)
 out={'seed':seed,'cases':len(s),'arms':{}}
 for m in [1,3,5]:
  t0=time.perf_counter_ns();dist=np.zeros((len(pbase),K),np.int16)
  for c in obs[:m]:dist+=np.count_nonzero(c[:,None,:]!=cent,axis=-1).astype(np.int16)
  pred=dist.argmin(1).reshape(a.shape);ans=chain(t,s,pred);elapsed=(time.perf_counter_ns()-t0)/1e6
  out['arms'][m]={'cue':float(np.mean(mapping[pred]==a)),'chain':float(np.mean(ans==y)),'elapsed_ms':elapsed}
 return out
if __name__=='__main__':
 p=Path(__file__).parent;rows=json.loads((p/'results.json').read_text())['runs'];out=[]
 for row in rows:
  res=run_follow(row['seed'],row);out.append(res);print(res,flush=True)
 (p/'noise_followup.json').write_text(json.dumps(out,indent=2))
