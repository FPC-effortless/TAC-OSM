Requires Python + PyTorch only. python runtime.py < demo-requests.jsonl
Public JSON-lines: reset, keys(2x16), events(new raw46-vectors), candidates(5x19), prices(sensor-error,inspection-price).
Events: source6(initial,relation,action-start,repair-receipt,exact-inspection,noise), subject16,other16,bit,action-type3,tick,exact,sensor-error,inspection-price.
Outputs: learned choice index, scores, joint probabilities(00,01,10,11), completion and two fault marginals in one forward pass.
Priors: public typed manifest, cosine identity binding, trained noise-type gate, FIFO64, two entity state labels.
No Bayes filter, teacher, physical transition function, analytical planner or stop override in deployment.
Posterior-supervised bounded research model; independent external verification remains necessary. No commercial or universal calibration claim.
