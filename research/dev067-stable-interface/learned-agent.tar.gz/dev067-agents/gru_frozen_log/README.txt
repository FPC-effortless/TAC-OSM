Requires Python + PyTorch only. python runtime.py < demo-requests.jsonl
Public JSON-lines: reset, keys(2x16), events(new raw46-vectors), candidates(5x19), prices(sensor-error,inspection-price).
Events: source6(initial,relation,action-start,repair-receipt,exact-inspection,noise), subject16,other16,bit,action-type3,tick,exact,sensor-error,inspection-price.
Outputs: learned choice index, scores, joint probabilities health4 xgraph3, health/relation marginals and action-conditioned outcomes in one forward pass. Healthy-state belief does not independently verify physical completion.
Priors: public typed manifest, cosine identity binding, trained noise-type gate, FIFO64, two entities, supplied12-state vocabulary, event-clock prior for relative arms. All arms structurally exclude parallel actor latents; semantic-target mixing and gradient isolation are training-only. This export always uses predicted beliefs.
No Bayes filter, teacher, physical transition function, analytical planner or stop override in deployment. Shared final encoders, equal4096module updates, float64 actors and generic probability/log coordinates are disclosed in metadata. Pilot-only exports are unqualified; no20seed evidence follows.
Optional runtime-batched.py uses unchanged gate weights and typed batched FIFO; see the independent runtime profile and parity audit.
DEV067 posterior-supervised bounded research model; training isolation/exposure recipe disclosed in metadata; independent external verification remains necessary. No commercial or universal calibration claim.
