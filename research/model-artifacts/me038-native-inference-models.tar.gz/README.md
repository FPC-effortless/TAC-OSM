# ME038 trained native forecasters

60 original validation-selected native models: 48 models across six datasets, four forecast horizons and two seeds in the
exposure lane, plus twelve separate compute-budget models. Whole 96-step histories are required for each forecast.
Input/output use raw publisher units, with channel order in data.json. Horizons
are dataset steps, not universally hours. Tetouan models have eight channels; the
last three Tetouan channels are zone power; first five are recorded weather.

    import torch
    model = torch.jit.load("models/exposure-ETTh1-h96-innovation_tac-s38001.jit.pt").eval()
    with torch.no_grad(): forecast = model(raw_history)  # B x 96 x 7

Run `python verify.py` with Torch and NumPy to hash all payloads and reproduce
bundled physical-unit validation probes exactly, without importing TAC or training.
Versions are in INDEX.json; CPU float32 reproducibility is scoped to this environment.
Training-only anchors have been removed; learned weights are unchanged.

See RESULTS.md for all outcomes, including every registered power gate outcome,
separate power-channel errors, prior benchmark exposure and unequal actual compute.
These are research forecasting components, not qualified action controllers,
causal world models, streaming deployments or commercial systems. The complete
archive also contains all 1,008 parent/adaptation checkpoints, optimizer/RNG states,
original sources and training traces. No published-model or compute-parity claim.
