---
tags:
- time-series
- forecasting
- anomaly-detection
- classification
- TSLib
license: cc-by-4.0
task_categories:
- time-series-forecasting
pretty_name: Time-Series-Library (TSLib)
language:
- en
configs:
- config_name: ETTh1
  description: ETT long-term forecasting subset ETTh1 (hourly).
  data_files:
  - ETT-small/ETTh1.csv
- config_name: ETTh2
  description: ETT long-term forecasting subset ETTh2 (hourly).
  data_files:
  - ETT-small/ETTh2.csv
- config_name: ETTm1
  description: ETT long-term forecasting subset ETTm1 (15-min).
  data_files:
  - ETT-small/ETTm1.csv
- config_name: ETTm2
  description: ETT long-term forecasting subset ETTm2 (15-min).
  data_files:
  - ETT-small/ETTm2.csv
- config_name: electricity
  description: Electricity load forecasting (UCI Electricity).
  data_files:
  - electricity/electricity.csv
- config_name: traffic
  description: Traffic volume forecasting.
  data_files:
  - traffic/traffic.csv
- config_name: weather
  description: Weather time-series forecasting.
  data_files:
  - weather/weather.csv
- config_name: exchange_rate
  description: Exchange rate forecasting.
  data_files:
  - exchange_rate/exchange_rate.csv
- config_name: national_illness
  description: Influenza-like illness (ILI) forecasting.
  data_files:
  - illness/national_illness.csv
- config_name: m4-yearly
  description: M4 Yearly forecasting subset.
  data_files:
  - split: train
    path: m4/Yearly-train.csv
  - split: test
    path: m4/Yearly-test.csv
- config_name: m4-quarterly
  description: M4 Quarterly forecasting subset.
  data_files:
  - split: train
    path: m4/Quarterly-train.csv
  - split: test
    path: m4/Quarterly-test.csv
- config_name: m4-monthly
  description: M4 Monthly forecasting subset.
  data_files:
  - split: train
    path: m4/Monthly-train.csv
  - split: test
    path: m4/Monthly-test.csv
- config_name: m4-weekly
  description: M4 Weekly forecasting subset.
  data_files:
  - split: train
    path: m4/Weekly-train.csv
  - split: test
    path: m4/Weekly-test.csv
- config_name: m4-daily
  description: M4 Daily forecasting subset.
  data_files:
  - split: train
    path: m4/Daily-train.csv
  - split: test
    path: m4/Daily-test.csv
- config_name: m4-hourly
  description: M4 Hourly forecasting subset.
  data_files:
  - split: train
    path: m4/Hourly-train.csv
  - split: test
    path: m4/Hourly-test.csv
- config_name: EthanolConcentration
  description: 'UEA multivariate classification: EthanolConcentration.'
  data_files:
  - split: train
    path: EthanolConcentration/EthanolConcentration_TRAIN.ts
  - split: test
    path: EthanolConcentration/EthanolConcentration_TEST.ts
- config_name: FaceDetection
  description: 'UEA multivariate classification: FaceDetection.'
  data_files:
  - split: train
    path: FaceDetection/FaceDetection_TRAIN.ts
  - split: test
    path: FaceDetection/FaceDetection_TEST.ts
- config_name: Handwriting
  description: 'UEA multivariate classification: Handwriting.'
  data_files:
  - split: train
    path: Handwriting/Handwriting_TRAIN.ts
  - split: test
    path: Handwriting/Handwriting_TEST.ts
- config_name: Heartbeat
  description: 'UEA multivariate classification: Heartbeat.'
  data_files:
  - split: train
    path: Heartbeat/Heartbeat_TRAIN.ts
  - split: test
    path: Heartbeat/Heartbeat_TEST.ts
- config_name: JapaneseVowels
  description: 'UEA multivariate classification: JapaneseVowels.'
  data_files:
  - split: train
    path: JapaneseVowels/JapaneseVowels_TRAIN.ts
  - split: test
    path: JapaneseVowels/JapaneseVowels_TEST.ts
- config_name: PEMS-SF
  description: 'UEA multivariate classification: PEMS-SF.'
  data_files:
  - split: train
    path: PEMS-SF/PEMS-SF_TRAIN.ts
  - split: test
    path: PEMS-SF/PEMS-SF_TEST.ts
- config_name: SelfRegulationSCP1
  description: 'UEA multivariate classification: SelfRegulationSCP1.'
  data_files:
  - split: train
    path: SelfRegulationSCP1/SelfRegulationSCP1_TRAIN.ts
  - split: test
    path: SelfRegulationSCP1/SelfRegulationSCP1_TEST.ts
- config_name: SelfRegulationSCP2
  description: 'UEA multivariate classification: SelfRegulationSCP2.'
  data_files:
  - split: train
    path: SelfRegulationSCP2/SelfRegulationSCP2_TRAIN.ts
  - split: test
    path: SelfRegulationSCP2/SelfRegulationSCP2_TEST.ts
- config_name: SpokenArabicDigits
  description: 'UEA multivariate classification: SpokenArabicDigits.'
  data_files:
  - split: train
    path: SpokenArabicDigits/SpokenArabicDigits_TRAIN.ts
  - split: test
    path: SpokenArabicDigits/SpokenArabicDigits_TEST.ts
- config_name: UWaveGestureLibrary
  description: 'UEA multivariate classification: UWaveGestureLibrary.'
  data_files:
  - split: train
    path: UWaveGestureLibrary/UWaveGestureLibrary_TRAIN.ts
  - split: test
    path: UWaveGestureLibrary/UWaveGestureLibrary_TEST.ts
- config_name: SMD-data
  description: Server Machine Dataset (SMD) for anomaly detection — train & test data.
  data_files:
  - split: train
    path: SMD/SMD_train.npy
  - split: test
    path: SMD/SMD_test.npy
- config_name: SMD-label
  description: Server Machine Dataset (SMD) — test anomaly labels.
  data_files:
  - split: test_label
    path: SMD/SMD_test_label.npy
- config_name: MSL-data
  description: NASA Mars Science Laboratory (MSL) anomaly detection — train/test arrays.
  data_files:
  - split: train
    path: MSL/MSL_train.npy
  - split: test
    path: MSL/MSL_test.npy
- config_name: MSL-label
  description: MSL anomaly detection — test labels.
  data_files:
  - split: test_label
    path: MSL/MSL_test_label.npy
- config_name: SMAP-data
  description: >-
    NASA Soil Moisture Active Passive (SMAP) anomaly detection — train/test
    arrays.
  data_files:
  - split: train
    path: SMAP/SMAP_train.npy
  - split: test
    path: SMAP/SMAP_test.npy
- config_name: SMAP-label
  description: SMAP anomaly detection — test labels.
  data_files:
  - split: test_label
    path: SMAP/SMAP_test_label.npy
- config_name: PSM-data
  description: KPI-based Process/System Monitoring data (train/test).
  data_files:
  - split: train
    path: PSM/train.csv
  - split: test
    path: PSM/test.csv
- config_name: PSM-label
  description: KPI-based Process/System Monitoring labels (test_label).
  data_files:
  - split: test_label
    path: PSM/test_label.csv
- config_name: SWaT
  description: Secure Water Treatment (SWaT) anomaly detection, processed data.
  data_files:
  - split: train
    path: SWaT/swat_train2.csv
  - split: test
    path: SWaT/swat2.csv
size_categories:
- 10M<n<100M
---


# Time-Series-Library (TSLib)

TSLib is an open-source library for deep learning researchers, especially for deep time series analysis.

We provide a neat code base to evaluate advanced deep time series models or develop your model, which covers five mainstream tasks: **long- and short-term forecasting, imputation, anomaly detection, and classification.**

This benchmark collection is designed to evaluate and develop advanced deep time-series models. For an in-depth exploration of current time-series models and their performance, please refer to our paper **[Deep Time Series Models: A Comprehensive Survey and Benchmark](https://arxiv.org/abs/2407.13278)**.

To get started with the codebase and contribute, please visit the **[GitHub repository](https://github.com/thuml/Time-Series-Library)**.

## Dataset Overview

| **Tasks**         | **Benchmarks**                                                                 | **Metrics**                          | **Series Length**     |
|-------------------|-------------------------------------------------------------------------------|--------------------------------------|-----------------------|
| **Forecasting**    | **Long-term:** ETT (4 subsets), Electricity, Traffic, Weather, Exchange, ILI  | MSE, MAE                             | 96\~720 (ILI: 24\~60)   |
|                   | **Short-term:** M4 (6 subsets)                                                | SMAPE, MASE, OWA                    | 6\~48                  |
| **Imputation**     | ETT (4 subsets), Electricity, Weather                                        | MSE, MAE                             | 96                    |
| **Classification** | UEA (10 subsets)                                                              | Accuracy                             | 29\~1751               |
| **Anomaly Detection** | SMD, MSL, SMAP, SWaT, PSM                                                  | Precision, Recall, F1-Score         | 100                   |


## File Structure
```
Time-Series-Library/
├── ETT-small/
├── EthanolConcentration/
├── FaceDetection/
├── Handwriting/
├── Heartbeat/
├── JapaneseVowels/
├── MSL/
├── PEMS-SF/
├── PSM/
├── SMAP/
├── SMD/
├── SWaT/
├── SelfRegulationSCP1/
├── SelfRegulationSCP2/
├── SpokenArabicDigits/
├── UWaveGestureLibrary/
├── electricity/
├── exchange_rate/
├── illness/
├── m4/
├── traffic/
├── weather/
├── .gitattributes
└── README.md
```

## Usage

You can load the dataset directly using the `datasets` library:

```
from datasets import load_dataset
dataset = load_dataset("thuml/Time-Series-Library", "ETTh1")
```

Or download specific files with hf_hub_download:

```
from huggingface_hub import hf_hub_download
hf_hub_download("thuml/Time-Series-Library", "ETT-small/ETTh1.csv", repo_type="dataset")
```

## License
This dataset is released under the CC BY 4.0 License.

## Citation

If you find this repo useful, please cite our paper.

```
@inproceedings{wu2023timesnet,
  title={TimesNet: Temporal 2D-Variation Modeling for General Time Series Analysis},
  author={Haixu Wu and Tengge Hu and Yong Liu and Hang Zhou and Jianmin Wang and Mingsheng Long},
  booktitle={International Conference on Learning Representations},
  year={2023},
}

@article{wang2024tssurvey,
  title={Deep Time Series Models: A Comprehensive Survey and Benchmark},
  author={Yuxuan Wang and Haixu Wu and Jiaxiang Dong and Yong Liu and Mingsheng Long and Jianmin Wang},
  booktitle={arXiv preprint arXiv:2407.13278},
  year={2024},
}
```