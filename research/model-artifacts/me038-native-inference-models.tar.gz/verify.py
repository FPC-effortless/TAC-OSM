import hashlib,json,numpy as np,torch
from pathlib import Path
torch.set_num_threads(1)
r=Path(__file__).resolve().parent;m=json.loads((r/'INDEX.json').read_text())
for p in m['payloads']:
 f=r/p['path'];assert f.stat().st_size==p['bytes'] and hashlib.sha256(f.read_bytes()).hexdigest()==p['sha256']
count=0
for row in m['models']:
 model=torch.jit.load(str(r/row['model'])).eval()
 with torch.no_grad():y=model(torch.from_numpy(np.load(r/row['input']))).numpy()
 assert np.array_equal(y,np.load(r/row['expected'])),row['key'];count+=y.size
print('PASS',len(m['models']),'native models;',count,'physical forecast values bit exact; no TAC package or refit')
