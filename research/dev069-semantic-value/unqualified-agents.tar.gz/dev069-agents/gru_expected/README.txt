Python + PyTorch only. python runtime.py < demo-requests.jsonl
Inputs: reset, keys2x16, new events Nx46, shuffled choices5x19, prices2, remaining_fraction.
State12 predicts paid inspection outcomes (healthpair4 x publicgraph3).
Future21 predicts next paired inspection12 or terminal verificationfaultcount3 x graph3.
Policy reads only learned future probabilities and cost plus public choices/prices/budget.
No analytical posterior, action teacher, physical law, search or forced stop at inference.
Explicit structure: typed schema, cosine identity binding, 2entities/5actions, state vocabulary, FIFO64 and supervised noise gate.
Outcome-arm training uses extra separately charged inspection labels WITHHELD from student history.
Teacher-control encoder alone uses explicit known-law public posterior targets.
Reported probabilities are unqualified learned estimates; external verification is required.
Pilot export is diagnostic; not commercially qualified or evidence of architectural superiority.

DEV069: all memory/world weights are frozen from rejected DEV068 parents.
Only the value readout is retrained. Expected arm uses learned outcome utilities
and learned positive cost sensitivity; no physical utility/action rule is supplied.
No whole-world-model, CASM superiority or commercial qualification.
