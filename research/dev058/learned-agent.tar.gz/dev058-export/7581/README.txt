Requires Python and PyTorch 2.14.1+cpu. Run: python runtime.py < requests.jsonl
Runnable recorded public trace: python runtime.py < demo-requests.jsonl
Compare its JSON lines with demo-expected.jsonl. No world package is needed.
One request per line: events (new public 22-vectors), candidates (13x11),
valid (13 booleans), queries (6x8), query_valid (6 booleans), reset (optional).
All values are public API features. Output index selects the supplied candidate.
Event features: kind one-hot4 (initial status, relation, receipt, noise),
primary opaque identity one-hot8, related identity one-hot8, status bit, tick/256.
Candidate: kind one-hot3 (stop, inspect, repair), opaque identity one-hot8.
Query: opaque identity one-hot8. Padding masks describe tensor padding only.
No simulator, teacher, TAC-OSM installation, analytic planner or hidden state is used.
Trained on the bounded DEV058 synthetic task; no industrial/general competence claim.
