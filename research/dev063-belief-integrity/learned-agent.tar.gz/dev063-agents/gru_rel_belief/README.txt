Requires Python + PyTorch only. python runtime.py < demo-requests.jsonl
Public JSON-lines: reset, keys(2x16), events(new raw46-vectors), candidates(5x19), prices(sensor-error,inspection-price).
Events: source6(initial,relation,action-start,repair-receipt,exact-inspection,noise), subject16,other16,bit,action-type3,tick,exact,sensor-error,inspection-price.
Outputs: learned choice index, scores, joint probabilities health4 xgraph3, health/relation marginals and action-conditioned outcomes in one forward pass. Healthy-state belief does not independently verify physical completion.
Priors: public typed manifest, cosine identity binding, trained noise-type gate, FIFO64, two entities, supplied12-state vocabulary, event-clock prior for relative arms. The belief-only arms structurally exclude the parallel latent actor input.
No Bayes filter, teacher, physical transition function, analytical planner or stop override in deployment.
Posterior-supervised bounded research model; independent external verification remains necessary. No commercial or universal calibration claim.
